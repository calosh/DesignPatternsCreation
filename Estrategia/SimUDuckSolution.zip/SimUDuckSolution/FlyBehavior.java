/**
 * Write a description of interface FlyBehavior here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface FlyBehavior  
{
    public boolean canFly();
    public void fly();
    public int getY();
    public void setY(int value);
}
