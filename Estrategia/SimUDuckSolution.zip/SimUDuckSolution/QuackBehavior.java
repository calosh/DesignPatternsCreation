/**
 * Write a description of class QuackBehavior here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface QuackBehavior  
{
   public void quack();
}
